<?php

define('LOCALHOST', 'localhost');
define('USERNAME', 'chat');
define('PASSWORD', 'chat');
define('DBNAME', 'chat');


define('CLASSES', 'classes/');

date_default_timezone_set('Asia/Calcutta');

$now = date('Y-m-d H:i:s');
$nowstamp = strtotime($now);

