<head>
	<link rel="stylesheet" href="css/social.css"/>
</head>
<section>
<ul class="social">
	<a class="ease-all" href="http://facebook.com/tapaljor"><i class="fa fa-facebook"></i></a>
	<a class="ease-all" href="http://twitter/tapaljor"><i class="fa fa-twitter"></i></a>
	<a class="ease-all" href="tapaljor@gmail.com"><i class="fa fa-google-plus"></i></a>
	<p> Copyright &copy; 6561 | <a href="information.php">FAQ</a></p>
</ul>
</section>
